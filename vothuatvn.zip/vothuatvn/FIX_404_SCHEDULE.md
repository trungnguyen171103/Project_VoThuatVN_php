# ✅ SỬA LỖI 404 - SCHEDULE MODAL

## 🐛 VẤN ĐỀ

Modal lịch học mở ra nhưng không load được dữ liệu, console báo lỗi:
```
Failed to load resource: 404 (Not Found)
schedules/class-week?class_id=2&week=2026-01-13
```

## 🔍 NGUYÊN NHÂN

URL thiếu prefix `admin/`:
- **URL lỗi:** `schedules/class-week`
- **URL đúng:** `admin/schedules/class-week`

**Tại sao:**
- Route đã được định nghĩa đúng trong `web.php`
- JavaScript dùng `route('admin.schedules.class-week')` - đúng
- Nhưng route cache cũ khiến URL generate sai

## ✅ CÁCH SỬA

**Bước 1: Clear cache**
```bash
cd d:\Project_VoThuatVN_php\vothuatvn
php artisan route:clear
php artisan cache:clear
php artisan view:clear
```

**Bước 2: Refresh browser**
- Hard refresh: `Ctrl + Shift + R`

**Bước 3: Test lại**
1. Mở trang Lịch học
2. Click "Xem lịch"
3. Modal sẽ load dữ liệu thành công!

---

## 🧪 XÁC NHẬN

Sau khi clear cache, kiểm tra URL trong DevTools Network:
- ✅ Phải là: `http://127.0.0.1:8000/admin/schedules/class-week?class_id=2&week=2026-01-13`
- ❌ KHÔNG phải: `http://127.0.0.1:8000/schedules/class-week?class_id=2&week=2026-01-13`

---

**Chạy lệnh clear cache rồi test lại nhé!** 🚀
