# 🚨 FIX LỖI GD LIBRARY

## ⚠️ VẤN ĐỀ

Lỗi: **"Call to undefined function imagecreatefromjpeg()"**

**Nguyên nhân:** Hosting của bạn **chưa cài PHP GD extension**.

---

## ✅ GIẢI PHÁP ĐƠN GIẢN

Tôi đã tạo version **KHÔNG CẦN GD library**:

### Thay đổi:
- ✅ Tăng giới hạn upload: 2MB → **5MB**
- ✅ Hỗ trợ: JPEG, PNG, GIF, WebP
- ✅ Lưu ảnh gốc (không resize)
- ✅ Không cần GD extension

### Bỏ:
- ❌ Auto resize (cần GD library)
- ❌ Tối ưu file size

---

## 📤 FILE CẦN UPLOAD

Upload file này lên hosting (overwrite):

```
app/Http/Controllers/Admin/ProfileController.php
```

---

## 🧪 TEST SAU KHI UPLOAD

1. **Upload ảnh nhỏ (< 2MB):**
   - ✅ Upload thành công
   - ✅ Ảnh hiển thị đúng

2. **Upload ảnh lớn (2MB - 5MB):**
   - ✅ Upload thành công
   - ⚠️ Ảnh giữ nguyên kích thước gốc

3. **Upload ảnh rất lớn (> 5MB):**
   - ❌ Hiện lỗi: "must not be greater than 5120 kilobytes"
   - 💡 Resize ảnh trước khi upload

---

## 💡 KHUYẾN NGHỊ

### Nếu muốn auto-resize ảnh:

**Cách 1: Cài GD extension (KHUYẾN NGHỊ)**

```bash
# Ubuntu/Debian
sudo apt-get install php-gd
sudo service apache2 restart

# CentOS/RHEL  
sudo yum install php-gd
sudo systemctl restart httpd

# cPanel
Enable "gd" trong PHP Extensions
```

**Cách 2: Resize ảnh trước khi upload**

Dùng tools online:
- https://tinypng.com/ (tối ưu PNG/JPEG)
- https://squoosh.app/ (resize + optimize)
- https://imagecompressor.com/

**Cách 3: Resize bằng JavaScript (client-side)**

Thêm vào form upload để resize ảnh trước khi gửi lên server.

---

## 🔧 NẾU MUỐN ENABLE GD

### Kiểm tra GD đã có chưa:

Tạo file `info.php`:
```php
<?php phpinfo(); ?>
```

Upload lên hosting, mở: `https://your-domain.com/info.php`

Tìm: **"GD Support"**
- ✅ **enabled** → GD đã có, dùng version có resize
- ❌ **not found** → GD chưa có, dùng version đơn giản

### Enable GD:

**Shared hosting (cPanel):**
1. cPanel > Software > Select PHP Version
2. Tìm "gd" trong Extensions
3. Check để enable
4. Save

**VPS/Dedicated:**
```bash
sudo apt-get install php-gd
sudo service apache2 restart
```

---

## 📊 SO SÁNH

| Tính năng | Version có GD | Version đơn giản |
|-----------|---------------|------------------|
| Max upload | 5MB | 5MB |
| Auto resize | ✅ | ❌ |
| Optimize size | ✅ | ❌ |
| Cần GD | ✅ | ❌ |
| Hoạt động ngay | ❌ (cần cài GD) | ✅ |

---

## 🚀 QUICK FIX

**NGAY BÂY GIỜ:**
1. ✅ Upload `ProfileController.php` (version đơn giản)
2. ✅ Test upload ảnh
3. ✅ Hoạt động ngay!

**SAU NÀY (nếu muốn):**
1. Enable GD extension
2. Upload version có auto-resize
3. Ảnh sẽ tự động tối ưu

---

## ⚠️ LƯU Ý

### Với version đơn giản:

- Ảnh lớn sẽ **không tự động resize**
- User cần **resize ảnh trước** khi upload
- Hoặc **giới hạn size nhỏ hơn** (1-2MB)

### Khuyến nghị:

Thêm thông báo trong form:
```html
<p class="small text-muted">
    Kích thước tối đa: 5MB. 
    Khuyến nghị resize ảnh xuống 800x800px trước khi upload.
</p>
```

---

**Upload file và test ngay! Sau đó có thể enable GD để có auto-resize.** 🎯
