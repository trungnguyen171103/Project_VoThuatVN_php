# 🔧 FIX NHANH - MENU KHÔNG ĐÓNG ĐƯỢC

## ✅ VẤN ĐỀ
Menu mở ra nhưng **không đóng được khi click vào overlay** (phần tối bên ngoài menu).

## 🎯 GIẢI PHÁP

### File cần sửa: `resources/views/layouts/admin.blade.php`

**TÌM ĐOẠN CODE NÀY (khoảng dòng 195-211):**

```css
.sidebar-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    backdrop-filter: blur(5px);
    z-index: 999;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.sidebar-overlay.active {
    opacity: 1;
}
```

**THAY BẰNG:**

```css
.sidebar-overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    backdrop-filter: blur(5px);
    z-index: 999;
    opacity: 0;
    transition: opacity 0.3s ease;
    pointer-events: none; /* ← THÊM DÒNG NÀY */
}

.sidebar-overlay.active {
    opacity: 1;
    pointer-events: auto; /* ← THÊM DÒNG NÀY */
}
```

---

## 📝 HOẶC SỬA TRONG @media (max-width: 991px)

**TÌM ĐOẠN NÀY (khoảng dòng 231-237):**

```css
.sidebar-overlay {
    display: none;
    pointer-events: none;
}

.sidebar-overlay.active {
    display: block;
    pointer-events: auto;
}
```

**ĐẢM BẢO CÓ `pointer-events: auto` trong `.sidebar-overlay.active`**

Nếu thiếu, thêm vào!

---

## ✅ SAU KHI SỬA

1. **Upload file** `admin.blade.php` lên hosting (overwrite)
2. **Clear cache:**
   ```bash
   php artisan view:clear
   ```
3. **Clear cache mobile browser**
4. **Test:**
   - Mở menu (click 3 gạch) ✅
   - Click vào phần tối bên ngoài → Menu phải đóng lại ✅

---

## 🎯 KẾT QUẢ

✅ Click 3 gạch → Menu mở  
✅ Click overlay (phần tối) → Menu đóng  
✅ Click menu items → Navigate  
✅ Tất cả buttons/links hoạt động  

---

**Đã sửa xong trên local! Chỉ cần upload file `admin.blade.php` lên hosting!**
