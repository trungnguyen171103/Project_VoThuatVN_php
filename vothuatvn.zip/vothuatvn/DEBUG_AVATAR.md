# 🔧 HƯỚNG DẪN TEST AVATAR LOCAL

## ✅ ĐÃ TẠO SYMLINK

Symlink đã được tạo thành công:
```
public/storage → storage/app/public
```

## 📸 ẢNH ĐÃ UPLOAD

File ảnh đã được lưu:
```
storage/app/public/avatars/kAt3RFKFhlj55Jk9qFPvFcJhlHj6G6heYAJY5RrR.jpg
```

## 🧪 KIỂM TRA NGAY

### 1. Mở browser console (F12)

### 2. Check ảnh có load được không:

Mở tab Network, filter "Images", refresh page.

Tìm request đến: `/storage/avatars/xxx.jpg`

- ✅ **200 OK** → Ảnh load được, vấn đề là CSS
- ❌ **404 Not Found** → Symlink chưa đúng
- ❌ **403 Forbidden** → Quyền folder sai

### 3. Test trực tiếp:

Mở URL này trong browser:
```
http://127.0.0.1:8000/storage/avatars/kAt3RFKFhlj55Jk9qFPvFcJhlHj6G6heYAJY5RrR.jpg
```

- ✅ Thấy ảnh → Symlink OK, vấn đề là view
- ❌ 404 → Symlink chưa đúng

### 4. Check database:

```bash
php artisan tinker
```

Trong tinker:
```php
$user = App\Models\User::find(YOUR_USER_ID);
echo $user->avatar;
```

Phải thấy:
```
avatars/kAt3RFKFhlj55Jk9qFPvFcJhlHj6G6heYAJY5RrR.jpg
```

Nếu `null` → Ảnh chưa lưu vào database!

---

## 🔍 NẾU AVATAR = NULL

### Nguyên nhân:

Form submit nhưng không lưu vào database.

### Giải pháp:

1. **Check form có `enctype`:**

Mở `resources/views/admin/profile/edit.blade.php`

Dòng 18 phải có:
```html
<form ... enctype="multipart/form-data">
```

2. **Check input có `name="avatar"`:**

Dòng 33 phải có:
```html
<input type="file" ... name="avatar">
```

3. **Test lại:**
   - Upload ảnh mới
   - Check database
   - Refresh page

---

## 🚀 QUICK FIX

Nếu vẫn không hiện, chạy:

```bash
# Clear cache
php artisan cache:clear
php artisan view:clear
php artisan config:clear

# Recreate symlink
rmdir public\storage
php artisan storage:link

# Restart server
# Ctrl+C để stop
php artisan serve
```

Sau đó test lại!

---

## 📞 DEBUG CHECKLIST

- [ ] Symlink đã tạo: `public/storage` exists
- [ ] File ảnh tồn tại: `storage/app/public/avatars/xxx.jpg`
- [ ] Database có avatar path: Check bằng tinker
- [ ] Form có `enctype="multipart/form-data"`
- [ ] Input có `name="avatar"`
- [ ] URL ảnh đúng: `/storage/avatars/xxx.jpg`
- [ ] Browser console không có 404 errors

---

**Làm theo checklist trên để tìm vấn đề!** 🔍
