

<?php $__env->startSection('title', 'Thêm CLB'); ?>
<?php $__env->startSection('page-title', 'Thêm Câu Lạc Bộ Mới'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="card animate-scale-in">
                <div class="card-body">
                    <form action="<?php echo e(route('admin.clubs.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label class="form-label">Tên CLB <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" required>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Chọn HLV</label>
                            <div class="coach-selection-box p-3 rounded" style="background: var(--color-bg-3); border: 1px solid var(--color-border);">
                                <div class="row g-2">
                                    <?php $__currentLoopData = $coaches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-6">
                                            <div class="form-check">
                                                <input class="form-check-input" type="checkbox" name="coaches[]" 
                                                    value="<?php echo e($coach->id); ?>" id="coach<?php echo e($coach->id); ?>"
                                                    <?php echo e((is_array(old('coaches')) && in_array($coach->id, old('coaches'))) ? 'checked' : ''); ?>>
                                                <label class="form-check-label fw-medium" for="coach<?php echo e($coach->id); ?>" style="color: var(--color-text-primary);">
                                                    <?php echo e($coach->user->name); ?> 
                                                    <small class="d-block" style="color: var(--color-text-muted);">(<?php echo e($coach->user->username); ?>)</small>
                                                </label>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-check-circle me-2"></i>Tạo CLB
                            </button>
                            <a href="<?php echo e(route('admin.clubs.index')); ?>" class="btn btn-secondary">
                                <i class="bi bi-x-circle me-2"></i>Hủy
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_VoThuatVN_php\vothuatvn\resources\views/admin/clubs/create.blade.php ENDPATH**/ ?>