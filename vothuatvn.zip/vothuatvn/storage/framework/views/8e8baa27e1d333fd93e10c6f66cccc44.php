

<?php $__env->startSection('title', 'Danh sách nợ'); ?>
<?php $__env->startSection('page-title', 'Danh Sách Học Phí'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mb-4">
        <div class="col-12">
            <a href="<?php echo e(route('admin.tuitions.create')); ?>" class="btn btn-primary">
                <i class="bi bi-plus-circle me-2"></i>Tạo học phí mới
            </a>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form method="GET" action="<?php echo e(route('admin.tuitions.debts')); ?>" id="filterForm">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Chọn Câu lạc bộ</label>
                                    <select id="clubFilter" name="club_id" class="form-control">
                                        <option value="">-- Tất cả câu lạc bộ --</option>
                                        <?php $__currentLoopData = $clubs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $club): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($club->id); ?>" <?php echo e(request('club_id') == $club->id ? 'selected' : ''); ?>>
                                                <?php echo e($club->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Chọn lớp học</label>
                                    <select id="classFilter" name="class_id" class="form-control" <?php echo e(!request('club_id') ? 'disabled' : ''); ?>>
                                        <option value="">-- Chọn câu lạc bộ trước --</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row mt-3">
                            <div class="col-12">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-funnel me-2"></i>Lọc
                                </button>
                                <a href="<?php echo e(route('admin.tuitions.debts')); ?>" class="btn btn-secondary">
                                    <i class="bi bi-x-circle me-2"></i>Xóa bộ lọc
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card animate-fade-in-up">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-cash-stack me-2"></i>Danh sách học phí</h5>
                </div>
                <div class="card-body">
                    <?php if($debts->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Võ sinh</th>
                                        <th>Lớp học</th>
                                        <th>Tháng</th>
                                        <th>Số tiền</th>
                                        <th>Trạng thái</th>
                                        <th>Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $debts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><strong><?php echo e($payment->student->full_name); ?></strong></td>
                                            <td><?php echo e($payment->tuition->classModel->name); ?></td>
                                            <td><?php echo e(str_pad($payment->tuition->month, 2, '0', STR_PAD_LEFT)); ?>/<?php echo e($payment->tuition->year); ?></td>
                                            <td><span class="text-danger fw-bold"><?php echo e(number_format($payment->amount)); ?> đ</span></td>
                                            <td>
                                                <?php if($payment->status === 'paid'): ?>
                                                    <span class="badge bg-success">Đã đóng</span>
                                                <?php elseif($payment->status === 'pending'): ?>
                                                    <span class="badge bg-warning">Chưa đóng</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">Quá hạn</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($payment->status !== 'paid'): ?>
                                                    <form action="<?php echo e(route('admin.tuitions.mark-paid', $payment->id)); ?>" method="POST" class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn btn-sm btn-outline-success">
                                                            <i class="bi bi-check-circle"></i> Đánh dấu đã đóng
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                                <a href="<?php echo e(route('admin.tuitions.print-bill', $payment->id)); ?>" class="btn btn-sm btn-outline-primary" target="_blank">
                                                    <i class="bi bi-printer"></i> In bill
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <?php echo e($debts->links()); ?>

                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="bi bi-inbox" style="font-size: 3rem; opacity: 0.3;"></i>
                            <p class="text-muted mt-3">Không có dữ liệu</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const clubFilter = document.getElementById('clubFilter');
    const classFilter = document.getElementById('classFilter');
    const selectedClassId = '<?php echo e(request("class_id")); ?>';

    // When club is selected, fetch classes
    clubFilter.addEventListener('change', async function() {
        const clubId = this.value;
        
        classFilter.innerHTML = '<option value="">-- Chọn lớp --</option>';
        classFilter.disabled = true;

        if (!clubId) {
            classFilter.innerHTML = '<option value="">-- Chọn câu lạc bộ trước --</option>';
            return;
        }

        try {
            const response = await fetch(`/admin/tuitions/clubs/${clubId}/classes`);
            const classes = await response.json();

            if (classes.length === 0) {
                classFilter.innerHTML = '<option value="">-- Không có lớp nào --</option>';
                return;
            }

            classes.forEach(cls => {
                const option = document.createElement('option');
                option.value = cls.id;
                option.textContent = `${cls.name} (${cls.class_code})`;
                if (cls.id == selectedClassId) {
                    option.selected = true;
                }
                classFilter.appendChild(option);
            });

            classFilter.disabled = false;
        } catch (error) {
            console.error('Error fetching classes:', error);
        }
    });

    // Trigger on page load if club is already selected
    if (clubFilter.value) {
        clubFilter.dispatchEvent(new Event('change'));
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_VoThuatVN_php\vothuatvn\resources\views/admin/tuitions/debts.blade.php ENDPATH**/ ?>