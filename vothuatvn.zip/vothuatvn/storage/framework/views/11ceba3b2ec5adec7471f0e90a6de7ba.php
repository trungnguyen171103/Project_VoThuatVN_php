

<?php $__env->startSection('title', 'Điểm danh'); ?>
<?php $__env->startSection('page-title', 'Điểm Danh Võ Sinh'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mb-4">
        <div class="col-12">
            <div class="card animate-fade-in">
                <div class="card-body">
                    <form action="<?php echo e(route('admin.attendances.index')); ?>" method="GET">
                        <div class="row align-items-end">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label">Chọn lớp học</label>
                                    <select name="class_id" class="form-control" required>
                                        <option value="">-- Chọn lớp --</option>
                                        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($class->id); ?>" <?php echo e(request('class_id') == $class->id ? 'selected' : ''); ?>>
                                                <?php echo e($class->name); ?> (<?php echo e($class->class_code); ?>)
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label">Ngày điểm danh</label>
                                    <input type="date" name="date" class="form-control"
                                        value="<?php echo e(request('date', date('Y-m-d'))); ?>" required>
                                </div>
                            </div>

                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label">&nbsp;</label>
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="bi bi-search me-2"></i>Xem danh sách
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php if(isset($students) && $students->count() > 0): ?>
        <div class="row">
            <div class="col-12">
                <div class="card animate-fade-in-up">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="bi bi-check2-square me-2"></i>
                            Điểm danh lớp <?php echo e($selectedClass->name); ?> -
                            <?php echo e(\Carbon\Carbon::parse(request('date'))->format('d/m/Y')); ?>

                        </h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('admin.attendances.mark')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="class_id" value="<?php echo e(request('class_id')); ?>">
                            <input type="hidden" name="date" value="<?php echo e(request('date')); ?>">

                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>STT</th>
                                            <th>Họ tên</th>
                                            <th>Năm sinh</th>
                                            <th>Trạng thái</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($index + 1); ?></td>
                                                <td><strong><?php echo e($student->full_name); ?></strong></td>
                                                <td><?php echo e($student->birth_year); ?></td>
                                                <td>
                                                    <input type="hidden" name="attendances[<?php echo e($index); ?>][student_id]" value="<?php echo e($student->id); ?>">
                                                    <select name="attendances[<?php echo e($index); ?>][status]"
                                                        class="form-select form-select-sm status-select-attendance" style="width: 160px;">
                                                        <option value="present" <?php echo e(($attendances[$student->id] ?? '') === 'present' ? 'selected' : ''); ?>>
                                                            ✓ Có mặt
                                                        </option>
                                                        <option value="absent" <?php echo e(($attendances[$student->id] ?? '') === 'absent' ? 'selected' : ''); ?>>
                                                            ✗ Vắng
                                                        </option>
                                                        <option value="excused" <?php echo e(($attendances[$student->id] ?? '') === 'excused' || ($attendances[$student->id] ?? '') === 'leave' ? 'selected' : ''); ?>>
                                                            P Nghỉ phép
                                                        </option>
                                                    </select>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>

                            <div class="mt-3">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-check-circle me-2"></i>Lưu điểm danh
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php elseif(request('class_id')): ?>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body text-center py-5">
                        <i class="bi bi-inbox" style="font-size: 3rem; opacity: 0.3;"></i>
                        <p class="text-muted mt-3">Lớp này chưa có võ sinh nào</p>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_VoThuatVN_php\vothuatvn\resources\views/admin/attendances/index.blade.php ENDPATH**/ ?>