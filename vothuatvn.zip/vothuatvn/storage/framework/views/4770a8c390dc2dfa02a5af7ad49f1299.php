

<?php $__env->startSection('title', 'Hồ sơ võ sinh'); ?>
<?php $__env->startSection('page-title', $student->full_name); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mb-4">
        <div class="col-12">
            <a href="<?php echo e(route('coach.students.index')); ?>" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Quay lại
            </a>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-person me-2"></i>Thông tin cá nhân</h5>
                </div>
                <div class="card-body">
                    <table class="table table-borderless">
                        <tr>
                            <td width="120"><strong>Họ tên:</strong></td>
                            <td><?php echo e($student->full_name); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Năm sinh:</strong></td>
                            <td><?php echo e($student->birth_year); ?></td>
                        </tr>
                        <tr>
                            <td><strong>SĐT:</strong></td>
                            <td><?php echo e($student->phone ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Địa chỉ:</strong></td>
                            <td><?php echo e($student->address ?? '-'); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-graph-up me-2"></i>Thống kê điểm danh</h5>
                </div>
                <div class="card-body">
                    <div class="row text-center">
                        <div class="col-md-4">
                            <h3 class="text-primary"><?php echo e($totalSessions); ?></h3>
                            <p class="text-muted">Tổng buổi học</p>
                        </div>
                        <div class="col-md-4">
                            <h3 class="text-success"><?php echo e($presentCount); ?></h3>
                            <p class="text-muted">Có mặt</p>
                        </div>
                        <div class="col-md-4">
                            <h3 class="text-danger"><?php echo e($attendanceRate); ?>%</h3>
                            <p class="text-muted">Tỷ lệ tham gia</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card mt-3">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-book me-2"></i>Lớp học</h5>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $student->classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mb-2">
                            <span class="badge bg-primary"><?php echo e($class->name); ?></span>
                            <small class="text-muted ms-2"><?php echo e($class->club->name); ?></small>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-clock-history me-2"></i>Lịch sử điểm danh</h5>
                </div>
                <div class="card-body">
                    <?php if($attendanceHistory->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Ngày</th>
                                        <th>Lớp học</th>
                                        <th>Trạng thái</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $attendanceHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($record->date->format('d/m/Y')); ?></td>
                                            <td><?php echo e($record->classModel->name); ?></td>
                                            <td>
                                                <?php if($record->status === 'present'): ?>
                                                    <span class="badge bg-success">Có mặt</span>
                                                <?php elseif($record->status === 'absent'): ?>
                                                    <span class="badge bg-danger">Vắng</span>
                                                <?php else: ?>
                                                    <span class="badge bg-warning">Vắng có phép</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <?php echo e($attendanceHistory->links()); ?>

                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="bi bi-inbox" style="font-size: 2rem; opacity: 0.3;"></i>
                            <p class="text-muted mt-2">Chưa có lịch sử điểm danh</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_VoThuatVN_php\vothuatvn\resources\views/coach/students/show.blade.php ENDPATH**/ ?>