

<?php $__env->startSection('title', 'Lịch điểm danh'); ?>
<?php $__env->startSection('page-title', 'Lịch Điểm Danh'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-calendar-month me-2"></i>Lịch dạy tháng <?php echo e(now()->format('m/Y')); ?></h5>
                </div>
                <div class="card-body">
                    <?php if($schedules->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Ngày</th>
                                        <th>Thời gian</th>
                                        <th>Lớp học</th>
                                        <th>Câu lạc bộ</th>
                                        <th>Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo e($schedule->date->format('d/m/Y')); ?></strong>
                                                <br>
                                                <small class="text-muted"><?php echo e($schedule->date->locale('vi')->dayName); ?></small>
                                            </td>
                                            <td><?php echo e($schedule->start_time); ?> - <?php echo e($schedule->end_time); ?></td>
                                            <td><strong><?php echo e($schedule->classModel->name); ?></strong></td>
                                            <td><?php echo e($schedule->classModel->club->name); ?></td>
                                            <td>
                                                <?php if($schedule->date <= now()): ?>
                                                    <a href="<?php echo e(route('coach.attendance.show', $schedule->id)); ?>"
                                                        class="btn btn-sm btn-primary">
                                                        <i class="bi bi-clipboard-check"></i> Điểm danh
                                                    </a>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">Chưa đến giờ</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="bi bi-calendar-x" style="font-size: 3rem; opacity: 0.3;"></i>
                            <p class="text-muted mt-3">Không có lịch dạy trong tháng này</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_VoThuatVN_php\vothuatvn\resources\views/coach/attendance/index.blade.php ENDPATH**/ ?>