

<?php $__env->startSection('title', 'Nhật ký hoạt động'); ?>
<?php $__env->startSection('page-title', 'Nhật Ký Hoạt Động'); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="row mb-4">
        <div class="col-12">
            <div class="card animate-fade-in-up"
                style="background: var(--color-bg-2); border: 1px solid var(--color-border);">
                <div class="card-body" style="background: var(--color-bg-2);">
                    <form action="<?php echo e(route('admin.activity-logs.index')); ?>" method="GET">
                        <div class="row align-items-end">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label class="form-label" style="color: var(--color-text-secondary);">Người dùng</label>
                                    <select name="user_id" class="form-select"
                                        style="background: var(--color-bg-3); border: 1px solid var(--color-border); color: var(--color-text-primary);">
                                        <option value="">Tất cả</option>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($user->id); ?>" <?php echo e(request('user_id') == $user->id ? 'selected' : ''); ?>>
                                                <?php echo e($user->name); ?> (<?php echo e($user->username); ?>)
                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label" style="color: var(--color-text-secondary);">Hành động</label>
                                    <select name="action" class="form-select"
                                        style="background: var(--color-bg-3); border: 1px solid var(--color-border); color: var(--color-text-primary);">
                                        <option value="">Tất cả</option>
                                        <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($action); ?>" <?php echo e(request('action') == $action ? 'selected' : ''); ?>>
                                                <?php echo e(\App\Services\ActivityLogger::getActionName($action)); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label" style="color: var(--color-text-secondary);">Từ ngày</label>
                                    <input type="date" name="from_date" class="form-control"
                                        value="<?php echo e(request('from_date')); ?>"
                                        style="background: var(--color-bg-3); border: 1px solid var(--color-border); color: var(--color-text-primary);">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label class="form-label" style="color: var(--color-text-secondary);">Đến ngày</label>
                                    <input type="date" name="to_date" class="form-control"
                                        value="<?php echo e(request('to_date')); ?>"
                                        style="background: var(--color-bg-3); border: 1px solid var(--color-border); color: var(--color-text-primary);">
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <input type="text" name="search" class="form-control"
                                        placeholder="Tìm kiếm mô tả..."
                                        value="<?php echo e(request('search')); ?>"
                                        style="background: var(--color-bg-3); border: 1px solid var(--color-border); color: var(--color-text-primary);">
                                </div>
                            </div>
                            <div class="col-md-1">
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="bi bi-search"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <?php if(request()->hasAny(['user_id', 'action', 'from_date', 'to_date', 'search'])): ?>
                            <div class="mt-2">
                                <a href="<?php echo e(route('admin.activity-logs.index')); ?>" class="btn btn-sm btn-outline-secondary">
                                    <i class="bi bi-x-circle me-1"></i>Xóa bộ lọc
                                </a>
                            </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row">
        <div class="col-12">
            <div class="card animate-fade-in-up"
                style="animation-delay: 0.1s; background: var(--color-bg-2); border: 1px solid var(--color-border);">
                <div class="card-header"
                    style="background: var(--color-bg-3); border-bottom: 1px solid var(--color-border);">
                    <h5 class="mb-0" style="color: var(--color-text-primary);">
                        <i class="bi bi-clock-history me-2"></i>Danh sách hoạt động
                        <span class="badge badge-primary ms-2"><?php echo e($logs->total()); ?> bản ghi</span>
                    </h5>
                </div>
                <div class="card-body" style="background: var(--color-bg-2);">
                    <?php if($logs->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover" style="background: var(--color-bg-2) !important;">
                                <thead style="background: var(--color-bg-3) !important;">
                                    <tr>
                                        <th style="color: var(--color-text-secondary) !important; width: 50px;">#</th>
                                        <th style="color: var(--color-text-secondary) !important;">Người dùng</th>
                                        <th style="color: var(--color-text-secondary) !important;">Hành động</th>
                                        <th style="color: var(--color-text-secondary) !important;">Mô tả</th>
                                        <th style="color: var(--color-text-secondary) !important;">IP</th>
                                        <th style="color: var(--color-text-secondary) !important;">Thiết bị</th>
                                        <th style="color: var(--color-text-secondary) !important;">Thời gian</th>
                                    </tr>
                                </thead>
                                <tbody style="background: var(--color-bg-2) !important;">
                                    <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr style="background: var(--color-bg-2) !important;">
                                            <td>
                                                <?php echo e($logs->firstItem() + $index); ?>

                                            </td>
                                            <td>
                                                <?php if($log->user): ?>
                                                    <strong><?php echo e($log->user->name); ?></strong>
                                                    <br>
                                                    <small class="text-muted"><?php echo e($log->user->username); ?></small>
                                                <?php else: ?>
                                                    <span class="text-muted">Người dùng đã xóa</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <span class="badge badge-<?php echo e($log->action_badge); ?>">
                                                    <?php echo e(\App\Services\ActivityLogger::getActionName($log->action)); ?>

                                                </span>
                                            </td>
                                            <td>
                                                <?php echo e($log->description); ?>

                                            </td>
                                            <td>
                                                <code>
                                                    <?php echo e($log->ip_address); ?>

                                                </code>
                                            </td>
                                            <td>
                                                <i class="bi bi-<?php echo e($log->device == 'Mobile' ? 'phone' : ($log->device == 'Tablet' ? 'tablet' : 'laptop')); ?>"></i>
                                                <?php echo e($log->device); ?>

                                            </td>
                                            <td>
                                                <?php echo e($log->created_at->format('d/m/Y H:i:s')); ?>

                                                <br>
                                                <small class="text-muted"><?php echo e($log->created_at->diffForHumans()); ?></small>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="mt-3">
                            <?php echo e($logs->links()); ?>

                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="bi bi-inbox"
                                style="font-size: 3rem; opacity: 0.3; color: var(--color-text-muted);"></i>
                            <p class="text-muted mt-3" style="color: var(--color-text-muted) !important;">
                                <?php if(request()->hasAny(['user_id', 'action', 'from_date', 'to_date', 'search'])): ?>
                                    Không tìm thấy hoạt động nào phù hợp
                                <?php else: ?>
                                    Chưa có nhật ký hoạt động nào
                                <?php endif; ?>
                            </p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_VoThuatVN_php\vothuatvn\resources\views/admin/activity_logs/index.blade.php ENDPATH**/ ?>