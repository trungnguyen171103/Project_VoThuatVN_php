

<?php $__env->startSection('title', 'Nợ học phí'); ?>
<?php $__env->startSection('page-title', 'Danh Sách Nợ Học Phí'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <form method="GET" action="<?php echo e(route('coach.debts.index')); ?>">
                        <div class="row">
                            <div class="col-md-6">
                                <label class="form-label">Lọc theo lớp học</label>
                                <select name="class_id" class="form-control" onchange="this.form.submit()">
                                    <option value="">-- Tất cả lớp học --</option>
                                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($class->id); ?>" <?php echo e(request('class_id') == $class->id ? 'selected' : ''); ?>>
                                            <?php echo e($class->name); ?> (<?php echo e($class->club->name); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-6 d-flex align-items-end">
                                <a href="<?php echo e(route('coach.debts.index')); ?>" class="btn btn-secondary">
                                    <i class="bi bi-x-circle"></i> Xóa bộ lọc
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-cash-stack me-2"></i>Danh sách nợ học phí</h5>
                </div>
                <div class="card-body">
                    <?php if($debts->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Võ sinh</th>
                                        <th>Lớp học</th>
                                        <th>Tháng</th>
                                        <th>Số tiền</th>
                                        <th>Trạng thái</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $debts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><strong><?php echo e($payment->student->full_name); ?></strong></td>
                                            <td><?php echo e($payment->tuition->classModel->name); ?></td>
                                            <td><?php echo e(str_pad($payment->tuition->month, 2, '0', STR_PAD_LEFT)); ?>/<?php echo e($payment->tuition->year); ?></td>
                                            <td><span class="text-danger fw-bold"><?php echo e(number_format($payment->amount)); ?> đ</span></td>
                                            <td>
                                                <?php if($payment->status === 'pending'): ?>
                                                    <span class="badge bg-warning">Chưa đóng</span>
                                                <?php else: ?>
                                                    <span class="badge bg-danger">Quá hạn</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <?php echo e($debts->links()); ?>

                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="bi bi-check-circle" style="font-size: 3rem; opacity: 0.3; color: #22c55e;"></i>
                            <p class="text-muted mt-3">Không có võ sinh nợ học phí</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_VoThuatVN_php\vothuatvn\resources\views/coach/debts/index.blade.php ENDPATH**/ ?>