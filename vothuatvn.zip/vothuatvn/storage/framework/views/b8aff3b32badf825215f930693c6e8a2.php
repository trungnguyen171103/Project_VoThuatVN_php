

<?php $__env->startSection('title', 'Kết quả tìm kiếm'); ?>
<?php $__env->startSection('page-title', 'Phân quyền HLV'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="card animate-scale-in">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-person-check me-2"></i>Thông tin tài khoản</h5>
                </div>
                <div class="card-body">
                    <table class="table">
                        <tr>
                            <th width="200">Tên đăng nhập:</th>
                            <td><code><?php echo e($user->username); ?></code></td>
                        </tr>
                        <tr>
                            <th>Họ và tên:</th>
                            <td><?php echo e($user->name); ?></td>
                        </tr>
                        <tr>
                            <th>Email:</th>
                            <td><?php echo e($user->email); ?></td>
                        </tr>
                        <tr>
                            <th>Số điện thoại:</th>
                            <td><?php echo e($user->phone ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <th>Vai trò hiện tại:</th>
                            <td>
                                <?php if($user->role === 'admin'): ?>
                                    <span class="badge bg-danger">Admin</span>
                                <?php elseif($user->role === 'coach'): ?>
                                    <span class="badge bg-success">HLV</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">User</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>Ngày đăng ký:</th>
                            <td><?php echo e($user->created_at->format('d/m/Y H:i')); ?></td>
                        </tr>
                        <tr>
                            <th>Trạng thái phân quyền:</th>
                            <td>
                                <?php if($isCoach): ?>
                                    <span class="badge bg-success"><i class="bi bi-check-circle"></i> Đã là HLV</span>
                                <?php else: ?>
                                    <span class="badge bg-warning"><i class="bi bi-exclamation-circle"></i> Chưa phân
                                        quyền</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>

                    <?php if(!$isCoach): ?>
                        <hr>
                        <form action="<?php echo e(route('admin.coaches.assign')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">

                            <div class="alert alert-warning">
                                <i class="bi bi-info-circle me-2"></i>
                                Bạn có chắc muốn phân quyền HLV cho tài khoản này?
                            </div>

                            <div class="d-flex gap-2 mt-3">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-check-circle me-2"></i>Phân quyền HLV
                                </button>
                                <a href="<?php echo e(route('admin.coaches.index')); ?>" class="btn btn-secondary">
                                    <i class="bi bi-arrow-left me-2"></i>Quay lại
                                </a>
                            </div>
                        </form>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i>
                            Tài khoản này đã được phân quyền HLV.
                        </div>
                        <a href="<?php echo e(route('admin.coaches.index')); ?>" class="btn btn-secondary">
                            <i class="bi bi-arrow-left me-2"></i>Quay lại danh sách
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_VoThuatVN_php\vothuatvn\resources\views/admin/coaches/search-result.blade.php ENDPATH**/ ?>