

<?php $__env->startSection('title', 'Kết quả tìm kiếm'); ?>
<?php $__env->startSection('page-title', 'Phân quyền HLV'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="card animate-scale-in">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-person-check me-2"></i>Thông tin tài khoản</h5>
                </div>
                <div class="card-body">
                    <div class="user-details">
                        <div class="row mb-3 pb-3 border-bottom">
                            <div class="col-md-4">
                                <strong>Tên đăng nhập:</strong>
                            </div>
                            <div class="col-md-8">
                                <code><?php echo e($user->username); ?></code>
                            </div>
                        </div>
                        <div class="row mb-3 pb-3 border-bottom">
                            <div class="col-md-4">
                                <strong>Họ và tên:</strong>
                            </div>
                            <div class="col-md-8">
                                <?php echo e($user->name); ?>

                            </div>
                        </div>
                        <div class="row mb-3 pb-3 border-bottom">
                            <div class="col-md-4">
                                <strong>Email:</strong>
                            </div>
                            <div class="col-md-8">
                                <?php echo e($user->email); ?>

                            </div>
                        </div>
                        <div class="row mb-3 pb-3 border-bottom">
                            <div class="col-md-4">
                                <strong>Số điện thoại:</strong>
                            </div>
                            <div class="col-md-8">
                                <?php echo e($user->phone ?? '-'); ?>

                            </div>
                        </div>
                        <div class="row mb-3 pb-3 border-bottom">
                            <div class="col-md-4">
                                <strong>Vai trò hiện tại:</strong>
                            </div>
                            <div class="col-md-8">
                                <?php if($user->role === 'admin'): ?>
                                    <span class="badge bg-danger">Admin</span>
                                <?php elseif($user->role === 'coach'): ?>
                                    <span class="badge bg-success">HLV</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">User</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="row mb-3 pb-3 border-bottom">
                            <div class="col-md-4">
                                <strong>Ngày đăng ký:</strong>
                            </div>
                            <div class="col-md-8">
                                <?php echo e($user->created_at->format('d/m/Y H:i')); ?>

                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <strong>Trạng thái phân quyền:</strong>
                            </div>
                            <div class="col-md-8">
                                <?php if($isCoach): ?>
                                    <span class="badge bg-success"><i class="bi bi-check-circle"></i> Đã là HLV</span>
                                <?php else: ?>
                                    <span class="badge bg-warning"><i class="bi bi-exclamation-circle"></i> Chưa phân
                                        quyền</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if(!$isCoach): ?>
                    <hr>
                    <form action="<?php echo e(route('admin.coaches.assign')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">

                        <div class="alert alert-warning">
                            <i class="bi bi-info-circle me-2"></i>
                            Bạn có chắc muốn phân quyền HLV cho tài khoản này?
                        </div>

                        <div class="d-flex gap-2 mt-3">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-check-circle me-2"></i>Phân quyền HLV
                            </button>
                            <a href="<?php echo e(route('admin.coaches.index')); ?>" class="btn btn-secondary">
                                <i class="bi bi-arrow-left me-2"></i>Quay lại
                            </a>
                        </div>
                    </form>
                <?php else: ?>
                    <div class="alert alert-info">
                        <i class="bi bi-info-circle me-2"></i>
                        Tài khoản này đã được phân quyền HLV.
                    </div>
                    <a href="<?php echo e(route('admin.coaches.index')); ?>" class="btn btn-secondary">
                        <i class="bi bi-arrow-left me-2"></i>Quay lại danh sách
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_VoThuatVN_php\vothuatvn\resources\views/admin/coaches/search-result.blade.php ENDPATH**/ ?>