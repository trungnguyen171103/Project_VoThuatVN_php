

<?php $__env->startSection('title', 'Chi tiết lớp học'); ?>
<?php $__env->startSection('page-title', $class->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mb-4">
        <div class="col-12">
            <a href="<?php echo e(route('coach.classes.index')); ?>" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left"></i> Quay lại
            </a>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-info-circle me-2"></i>Thông tin lớp học</h5>
                </div>
                <div class="card-body">
                    <table class="table table-borderless">
                        <tr>
                            <td width="150"><strong>Mã lớp:</strong></td>
                            <td><code><?php echo e($class->class_code); ?></code></td>
                        </tr>
                        <tr>
                            <td><strong>Câu lạc bộ:</strong></td>
                            <td><?php echo e($class->club->name); ?></td>
                        </tr>
                        <tr>
                            <td><strong>Sĩ số:</strong></td>
                            <td><?php echo e($class->students->count()); ?>/<?php echo e($class->max_students); ?> võ sinh</td>
                        </tr>
                        <tr>
                            <td><strong>Thời gian:</strong></td>
                            <td>
                                <?php echo e($class->start_date->format('d/m/Y')); ?>

                                <?php if($class->end_date): ?>
                                    - <?php echo e($class->end_date->format('d/m/Y')); ?>

                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><strong>Trạng thái:</strong></td>
                            <td>
                                <?php if($class->status === 'active'): ?>
                                    <span class="badge bg-success">Hoạt động</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Kết thúc</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-file-text me-2"></i>Mô tả</h5>
                </div>
                <div class="card-body">
                    <p><?php echo e($class->description ?? 'Chưa có mô tả'); ?></p>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-people me-2"></i>Danh sách võ sinh (<?php echo e($class->students->count()); ?>)
                    </h5>
                </div>
                <div class="card-body">
                    <?php if($class->students->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>STT</th>
                                        <th>Họ tên</th>
                                        <th>Năm sinh</th>
                                        <th>SĐT</th>
                                        <th>Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $class->students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($index + 1); ?></td>
                                            <td><strong><?php echo e($student->full_name); ?></strong></td>
                                            <td><?php echo e($student->birth_year); ?></td>
                                            <td><?php echo e($student->phone ?? '-'); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('coach.students.show', $student->id)); ?>"
                                                    class="btn btn-sm btn-outline-primary">
                                                    <i class="bi bi-eye"></i> Xem
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="bi bi-inbox" style="font-size: 2rem; opacity: 0.3;"></i>
                            <p class="text-muted mt-2">Chưa có võ sinh nào</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_VoThuatVN_php\vothuatvn\resources\views/coach/classes/show.blade.php ENDPATH**/ ?>