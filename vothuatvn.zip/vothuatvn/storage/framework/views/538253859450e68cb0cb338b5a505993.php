

<?php $__env->startSection('title', 'Lịch dạy'); ?>
<?php $__env->startSection('page-title', 'Lịch Dạy'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-calendar3 me-2"></i>Lịch dạy của tôi</h5>
                </div>
                <div class="card-body">
                    <?php if($schedules->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Ngày</th>
                                        <th>Thời gian</th>
                                        <th>Lớp học</th>
                                        <th>Câu lạc bộ</th>
                                        <th>Trạng thái</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <strong><?php echo e($schedule->date->format('d/m/Y')); ?></strong>
                                                <br>
                                                <small class="text-muted"><?php echo e($schedule->date->locale('vi')->dayName); ?></small>
                                            </td>
                                            <td><?php echo e($schedule->start_time); ?> - <?php echo e($schedule->end_time); ?></td>
                                            <td><strong><?php echo e($schedule->classModel->name); ?></strong></td>
                                            <td><?php echo e($schedule->classModel->club->name); ?></td>
                                            <td>
                                                <?php if($schedule->date < now()->startOfDay()): ?>
                                                    <span class="badge bg-secondary">Đã qua</span>
                                                <?php elseif($schedule->date->isToday()): ?>
                                                    <span class="badge bg-success">Hôm nay</span>
                                                <?php else: ?>
                                                    <span class="badge bg-primary">Sắp tới</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="bi bi-calendar-x" style="font-size: 3rem; opacity: 0.3;"></i>
                            <p class="text-muted mt-3">Không có lịch dạy</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_VoThuatVN_php\vothuatvn\resources\views/coach/schedule/index.blade.php ENDPATH**/ ?>