

<?php $__env->startSection('title', 'Sửa Võ sinh'); ?>
<?php $__env->startSection('page-title', 'Chỉnh Sửa Thông Tin Võ Sinh'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="card animate-scale-in">
                <div class="card-body">
                    <form action="<?php echo e(route('admin.students.update', $student->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Họ và tên <span class="text-danger">*</span></label>
                                    <input type="text" name="full_name" class="form-control"
                                        value="<?php echo e(old('full_name', $student->full_name)); ?>" required>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Năm sinh <span class="text-danger">*</span></label>
                                    <input type="number" name="birth_year" class="form-control"
                                        value="<?php echo e(old('birth_year', $student->birth_year)); ?>" min="1950"
                                        max="<?php echo e(date('Y')); ?>" required>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Số điện thoại <span class="text-danger">*</span></label>
                                    <input type="tel" name="phone" class="form-control"
                                        value="<?php echo e(old('phone', $student->phone)); ?>" required>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label class="form-label">Ngày đăng ký <span class="text-danger">*</span></label>
                                    <input type="date" name="registration_date" class="form-control"
                                        value="<?php echo e(old('registration_date', $student->registration_date ? \Carbon\Carbon::parse($student->registration_date)->format('Y-m-d') : '')); ?>"
                                        required>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Địa chỉ <span class="text-danger">*</span></label>
                            <textarea name="address" class="form-control" rows="2"
                                required><?php echo e(old('address', $student->address)); ?></textarea>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Trạng thái <span class="text-danger">*</span></label>
                            <select name="status" class="form-control" required>
                                <option value="active" <?php echo e(old('status', $student->status) === 'active' ? 'selected' : ''); ?>>
                                    Đang học</option>
                                <option value="inactive" <?php echo e(old('status', $student->status) === 'inactive' ? 'selected' : ''); ?>>Nghỉ học</option>
                            </select>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-check-circle me-2"></i>Cập nhật
                            </button>
                            <a href="<?php echo e(route('admin.students.index')); ?>" class="btn btn-secondary">
                                <i class="bi bi-x-circle me-2"></i>Hủy
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_VoThuatVN_php\vothuatvn\resources\views/admin/students/edit.blade.php ENDPATH**/ ?>