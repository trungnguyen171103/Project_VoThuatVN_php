

<?php $__env->startSection('title', 'Lớp học của tôi'); ?>
<?php $__env->startSection('page-title', 'Lớp Học Của Tôi'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="card hover-lift animate-fade-in-up" style="animation-delay: <?php echo e($loop->index * 0.05); ?>s">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-3">
                            <div>
                                <h5 class="card-title text-gradient mb-1"><?php echo e($class->name); ?></h5>
                                <code class="text-muted"><?php echo e($class->class_code); ?></code>
                            </div>
                            <?php if($class->status === 'active'): ?>
                                <span class="badge bg-success">Hoạt động</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Kết thúc</span>
                            <?php endif; ?>
                        </div>

                        <div class="mb-3">
                            <p class="mb-2 text-sm">
                                <i class="bi bi-building me-2 text-primary"></i><?php echo e($class->club->name); ?>

                            </p>
                            <p class="mb-2 text-sm">
                                <i class="bi bi-people me-2 text-primary"></i>
                                <?php echo e($class->students_count); ?>/<?php echo e($class->max_students); ?> võ sinh
                            </p>
                            <p class="mb-0 text-sm">
                                <i class="bi bi-calendar me-2 text-primary"></i>
                                <?php echo e($class->start_date->format('d/m/Y')); ?>

                                <?php if($class->end_date): ?>
                                    - <?php echo e($class->end_date->format('d/m/Y')); ?>

                                <?php endif; ?>
                            </p>
                        </div>

                        <a href="<?php echo e(route('coach.classes.show', $class->id)); ?>" class="btn btn-sm btn-outline-primary w-100">
                            <i class="bi bi-eye"></i> Xem chi tiết
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="card">
                    <div class="card-body text-center py-5">
                        <i class="bi bi-book" style="font-size: 3rem; opacity: 0.3;"></i>
                        <p class="text-muted mt-3">Bạn chưa được phân công lớp học nào</p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <?php if($classes->hasPages()): ?>
        <div class="row">
            <div class="col-12">
                <?php echo e($classes->links()); ?>

            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_VoThuatVN_php\vothuatvn\resources\views/coach/classes/index.blade.php ENDPATH**/ ?>