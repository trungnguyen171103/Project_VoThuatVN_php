

<?php $__env->startSection('title', 'Quản lý HLV'); ?>
<?php $__env->startSection('page-title', 'Quản lý Huấn Luyện Viên'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row mb-4">
        <div class="col-12">
            <div class="card animate-fade-in-up">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="bi bi-search me-2"></i>Tìm kiếm tài khoản để phân quyền HLV</h5>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('admin.coaches.search')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row align-items-end">
                            <div class="col-md-8">
                                <div class="form-group">
                                    <label class="form-label">Tên đăng nhập</label>
                                    <input type="text" name="username" class="form-control"
                                        placeholder="Nhập tên đăng nhập..." required>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label class="form-label">&nbsp;</label>
                                    <button type="submit" class="btn btn-primary w-100">
                                        <i class="bi bi-search me-2"></i>Tìm kiếm
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card animate-fade-in-up" style="animation-delay: 0.1s">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="bi bi-list-ul me-2"></i>Danh sách HLV</h5>
                    <span class="badge bg-primary"><?php echo e($coaches->total()); ?> HLV</span>
                </div>
                <div class="card-body">
                    <?php if($coaches->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>STT</th>
                                        <th>Tên đăng nhập</th>
                                        <th>Họ và tên</th>
                                        <th>Email</th>
                                        <th>SĐT</th>
                                        <th>Ngày tạo</th>
                                        <th>Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $coaches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $coach): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($coaches->firstItem() + $index); ?></td>
                                            <td><code><?php echo e($coach->user->username); ?></code></td>
                                            <td><?php echo e($coach->user->name); ?></td>
                                            <td><?php echo e($coach->user->email); ?></td>
                                            <td><?php echo e($coach->user->phone ?? '-'); ?></td>
                                            <td><?php echo e($coach->created_at->format('d/m/Y')); ?></td>
                                            <td>
                                                <form action="<?php echo e(route('admin.coaches.destroy', $coach->id)); ?>" method="POST"
                                                    class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="button" class="btn btn-sm btn-outline-danger"
                                                        onclick="handleDeleteForm(this, 'Bạn có chắc muốn xóa quyền HLV của <strong><?php echo e($coach->user->name); ?></strong>?')">
                                                        <i class="bi bi-trash"></i> Xóa
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="mt-3">
                            <?php echo e($coaches->links()); ?>

                        </div>
                    <?php else: ?>
                        <div class="text-center py-5">
                            <i class="bi bi-inbox" style="font-size: 3rem; opacity: 0.3;"></i>
                            <p class="text-muted mt-3">Chưa có HLV nào được phân quyền</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_VoThuatVN_php\vothuatvn\resources\views/admin/coaches/index.blade.php ENDPATH**/ ?>