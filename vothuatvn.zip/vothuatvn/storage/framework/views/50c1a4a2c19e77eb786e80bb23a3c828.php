

<?php $__env->startSection('title', 'Dashboard HLV'); ?>
<?php $__env->startSection('page-title', 'Dashboard Huấn Luyện Viên'); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card stat-card animate-fade-in">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="text-muted mb-1">Tổng số lớp</p>
                            <h3 class="mb-0"><?php echo e($totalClasses); ?></h3>
                        </div>
                        <div class="stat-icon bg-primary">
                            <i class="bi bi-book"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card stat-card animate-fade-in" style="animation-delay: 0.1s">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="text-muted mb-1">Tổng số võ sinh</p>
                            <h3 class="mb-0"><?php echo e($totalStudents); ?></h3>
                        </div>
                        <div class="stat-icon bg-success">
                            <i class="bi bi-people"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card stat-card animate-fade-in" style="animation-delay: 0.2s">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="text-muted mb-1">Võ sinh nợ phí</p>
                            <h3 class="mb-0 text-danger"><?php echo e($studentsWithDebt->count()); ?></h3>
                        </div>
                        <div class="stat-icon bg-danger">
                            <i class="bi bi-exclamation-triangle"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row mb-4">
        <div class="col-12">
            <div class="card animate-fade-in-up">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-calendar-check me-2"></i>Lịch dạy hôm nay</h5>
                </div>
                <div class="card-body">
                    <?php if($todaySchedules->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Thời gian</th>
                                        <th>Lớp học</th>
                                        <th>Câu lạc bộ</th>
                                        <th>Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $todaySchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($schedule->start_time); ?> - <?php echo e($schedule->end_time); ?></td>
                                            <td><strong><?php echo e($schedule->classModel->name); ?></strong></td>
                                            <td><?php echo e($schedule->classModel->club->name); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('coach.attendance.show', $schedule->id)); ?>"
                                                    class="btn btn-sm btn-primary">
                                                    <i class="bi bi-clipboard-check"></i> Điểm danh
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="bi bi-calendar-x" style="font-size: 3rem; opacity: 0.3;"></i>
                            <p class="text-muted mt-2">Không có lịch dạy hôm nay</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        
        <div class="col-md-6 mb-4">
            <div class="card animate-fade-in-up">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-book me-2"></i>Lớp học của tôi</h5>
                </div>
                <div class="card-body">
                    <?php if($classes->count() > 0): ?>
                        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="class-item mb-3 p-3"
                                style="background: rgba(220, 38, 38, 0.05); border-left: 3px solid #dc2626; border-radius: 8px;">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="mb-1"><?php echo e($class->name); ?></h6>
                                        <small class="text-muted"><?php echo e($class->club->name); ?></small>
                                        <p class="mb-0 mt-2">
                                            <i class="bi bi-people me-1"></i>
                                            <?php echo e($class->students_count); ?>/<?php echo e($class->max_students); ?> võ sinh
                                        </p>
                                    </div>
                                    <a href="<?php echo e(route('coach.classes.show', $class->id)); ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-eye"></i> Xem
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="bi bi-inbox" style="font-size: 2rem; opacity: 0.3;"></i>
                            <p class="text-muted mt-2">Chưa có lớp học nào</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        
        <div class="col-md-6 mb-4">
            <div class="card animate-fade-in-up" style="animation-delay: 0.1s">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-exclamation-triangle me-2"></i>Võ sinh vắng nhiều</h5>
                </div>
                <div class="card-body">
                    <?php if($frequentlyAbsentStudents->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Võ sinh</th>
                                        <th>Số buổi vắng</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $frequentlyAbsentStudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($record->student->full_name); ?></td>
                                            <td><span class="badge bg-warning"><?php echo e($record->absent_count); ?> buổi</span></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4">
                            <i class="bi bi-check-circle" style="font-size: 2rem; opacity: 0.3; color: #22c55e;"></i>
                            <p class="text-muted mt-2">Không có võ sinh vắng nhiều</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Project_VoThuatVN_php\vothuatvn\resources\views/coach/dashboard.blade.php ENDPATH**/ ?>