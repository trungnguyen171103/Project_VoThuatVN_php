# 🖼️ FIX LỖI AVATAR KHÔNG HIỂN THỊ

## ✅ VẤN ĐỀ

Avatar **đã upload thành công** ("Cập nhật hồ sơ thành công!") nhưng **không hiển thị ảnh**.

## 🎯 NGUYÊN NHÂN

File ảnh được lưu vào:
```
storage/app/public/avatars/xxx.jpg
```

Nhưng Laravel cần **symlink** để truy cập qua web:
```
public/storage → storage/app/public
```

**Symlink chưa được tạo** → Ảnh không truy cập được!

---

## 🔧 GIẢI PHÁP

### Cách 1: Chạy Artisan Command (KHUYẾN NGHỊ)

**Trên hosting có SSH:**
```bash
cd /path/to/your/project
php artisan storage:link
```

**Kết quả:**
```
The [public/storage] link has been connected to [storage/app/public].
The links have been created.
```

### Cách 2: Tạo Symlink Thủ Công (Nếu không có SSH)

**Trên hosting qua cPanel/File Manager:**

1. **Kiểm tra folder tồn tại:**
   - Navigate đến: `storage/app/public`
   - Phải thấy folder `avatars` với file ảnh bên trong

2. **Tạo symlink:**
   
   **Nếu hosting hỗ trợ symlink:**
   - Vào `public/` folder
   - Tạo symbolic link tên `storage` trỏ đến `../storage/app/public`

   **Nếu không hỗ trợ symlink:**
   - Copy toàn bộ folder `storage/app/public` vào `public/storage`
   - (Cách này không tối ưu nhưng sẽ hoạt động)

### Cách 3: Tạo Route Fallback (Giải pháp tạm thời)

Thêm vào `routes/web.php`:

```php
Route::get('/storage/{path}', function ($path) {
    $file = storage_path('app/public/' . $path);
    
    if (!file_exists($file)) {
        abort(404);
    }
    
    return response()->file($file);
})->where('path', '.*');
```

---

## 🧪 KIỂM TRA SAU KHI FIX

### 1. Kiểm tra symlink đã tạo

**Qua SSH:**
```bash
ls -la public/storage
```

Phải thấy:
```
storage -> ../storage/app/public
```

**Qua browser:**
Truy cập: `https://your-domain.com/storage/avatars/`

Phải thấy danh sách file hoặc 403 Forbidden (OK), không phải 404.

### 2. Test upload avatar

1. Vào "Hồ sơ cá nhân"
2. Click nút camera
3. Chọn ảnh
4. Click "Cập nhật thông tin"
5. **Ảnh phải hiển thị ngay!** ✅

### 3. Kiểm tra path trong database

**Qua phpMyAdmin:**
```sql
SELECT id, username, name, avatar FROM users WHERE id = YOUR_ID;
```

Phải thấy:
```
avatar: avatars/xxxxx.jpg
```

**Không phải:**
```
avatar: storage/avatars/xxxxx.jpg  ❌
avatar: /storage/avatars/xxxxx.jpg  ❌
```

---

## 🔍 DEBUG NẾU VẪN KHÔNG HIỂN THỊ

### Lỗi 1: 404 Not Found

**Nguyên nhân:** Symlink chưa tạo hoặc path sai

**Kiểm tra:**
```bash
# Check symlink
ls -la public/storage

# Check file exists
ls -la storage/app/public/avatars/
```

**Fix:**
```bash
# Remove old symlink (if exists)
rm public/storage

# Create new symlink
php artisan storage:link
```

### Lỗi 2: 403 Forbidden

**Nguyên nhân:** Quyền folder không đúng

**Fix:**
```bash
chmod -R 755 storage/app/public
chmod -R 755 public/storage
```

### Lỗi 3: Ảnh vẫn không hiện

**Kiểm tra trong code:**

Mở `resources/views/layouts/admin.blade.php`, tìm dòng:

```php
<img src="{{ asset('storage/' . Auth::user()->avatar) }}" ...>
```

Phải có `storage/` prefix!

**Kiểm tra trong browser:**

View source, tìm thẻ img, phải thấy:
```html
<img src="https://your-domain.com/storage/avatars/xxx.jpg">
```

Không phải:
```html
<img src="https://your-domain.com/avatars/xxx.jpg">  ❌
```

---

## 📁 CẤU TRÚC FOLDER ĐÚNG

```
project/
├── public/
│   ├── storage/  ← Symlink đến storage/app/public
│   ├── css/
│   └── js/
├── storage/
│   └── app/
│       └── public/
│           └── avatars/  ← Ảnh được lưu ở đây
│               └── xxx.jpg
```

**Truy cập qua web:**
```
https://domain.com/storage/avatars/xxx.jpg
                   ↑
                   Qua symlink
```

---

## 💡 LƯU Ý

### Khi deploy lên hosting mới:

1. **Luôn chạy:**
   ```bash
   php artisan storage:link
   ```

2. **Set quyền folder:**
   ```bash
   chmod -R 755 storage
   chmod -R 755 bootstrap/cache
   ```

3. **Check .gitignore:**
   ```
   /storage/*.key
   /storage/app/*
   !/storage/app/public
   /storage/framework/*
   ```

### Nếu hosting không hỗ trợ symlink:

**Giải pháp 1:** Sử dụng route fallback (Cách 3 ở trên)

**Giải pháp 2:** Lưu ảnh trực tiếp vào `public/avatars`

Sửa trong `ProfileController.php`:
```php
// Thay vì:
$path = $request->file('avatar')->store('avatars', 'public');

// Dùng:
$path = $request->file('avatar')->move(public_path('avatars'), $filename);
$data['avatar'] = 'avatars/' . $filename;
```

---

## 🚀 QUICK FIX

**Nếu có SSH:**
```bash
cd /path/to/project
php artisan storage:link
chmod -R 755 storage/app/public
```

**Nếu không có SSH:**
1. Copy folder `storage/app/public` vào `public/storage`
2. Hoặc thêm route fallback vào `routes/web.php`

**Test:**
- Upload avatar mới
- Refresh page
- Ảnh phải hiển thị! ✅

---

**Chạy `php artisan storage:link` là giải pháp tốt nhất!** 🎯
